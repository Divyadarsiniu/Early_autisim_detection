
import { createContext, useState, useContext, ReactNode } from "react";
import { AnalysisResult } from "../services/api";

interface UserContextType {
  name: string;
  setName: (name: string) => void;
  age: number;
  setAge: (age: number) => void;
  videoFile: File | null;
  setVideoFile: (file: File | null) => void;
  analysisResult: AnalysisResult | null;
  setAnalysisResult: (result: AnalysisResult | null) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const [name, setName] = useState<string>("");
  const [age, setAge] = useState<number>(0);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  return (
    <UserContext.Provider
      value={{
        name,
        setName,
        age,
        setAge,
        videoFile,
        setVideoFile,
        analysisResult,
        setAnalysisResult,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
};
