
import React from 'react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface GradientButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  className?: string;
  variant?: "default" | "outline" | "ghost";
}

const GradientButton = ({ 
  children, 
  className, 
  variant = "default",
  ...props 
}: GradientButtonProps) => {
  return (
    <Button
      className={cn(
        "font-medium",
        variant === "default" && "btn-gradient text-white border-none shadow-md",
        variant === "outline" && "bg-transparent border border-autism-purple text-autism-purple hover:bg-autism-soft-purple",
        variant === "ghost" && "bg-transparent text-autism-purple hover:bg-autism-soft-purple border-none",
        className
      )}
      {...props}
    >
      {children}
    </Button>
  );
};

export default GradientButton;
