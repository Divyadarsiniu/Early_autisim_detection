
import { useState, ChangeEvent } from "react";
import { useToast } from "@/components/ui/use-toast";
import { Upload } from "lucide-react";
import GradientButton from "./GradientButton";

interface VideoUploaderProps {
  onVideoUploaded: (file: File) => void;
}

const VideoUploader = ({ onVideoUploaded }: VideoUploaderProps) => {
  const { toast } = useToast();
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragging) {
      setIsDragging(true);
    }
  };

  const validateFile = (file: File): boolean => {
    // Check if the file is a video
    if (!file.type.startsWith("video/")) {
      toast({
        title: "Invalid file type",
        description: "Please upload a video file.",
        variant: "destructive",
      });
      return false;
    }

    // Check if the file is too large (100MB)
    const maxSize = 100 * 1024 * 1024; // 100MB in bytes
    if (file.size > maxSize) {
      toast({
        title: "File too large",
        description: "Please upload a video smaller than 100MB.",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      processFile(file);
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!validateFile(file)) return;

    setUploadedFile(file);
    onVideoUploaded(file);

    // Create a preview URL for the video
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  return (
    <div className="w-full flex flex-col items-center space-y-4">
      <div
        className={`w-full h-64 border-2 border-dashed rounded-lg flex flex-col items-center justify-center p-6 transition-all ${
          isDragging
            ? "border-autism-purple bg-autism-soft-purple"
            : "border-gray-300 hover:border-autism-purple"
        }`}
        onDragEnter={handleDragEnter}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleFileDrop}
      >
        {previewUrl ? (
          <video
            className="w-full h-full object-contain rounded-lg"
            src={previewUrl}
            controls
          />
        ) : (
          <>
            <Upload size={48} className="text-autism-purple mb-4" />
            <p className="text-lg font-medium text-center mb-2">
              Drag and drop your video here
            </p>
            <p className="text-sm text-gray-500 text-center mb-4">
              or click to select a file
            </p>
            <input
              type="file"
              id="video-upload"
              className="hidden"
              accept="video/*"
              onChange={handleFileChange}
            />
            <label htmlFor="video-upload">
              <GradientButton type="button" as="span" tabIndex={0}>
                Upload Video
              </GradientButton>
            </label>
          </>
        )}
      </div>

      {uploadedFile && (
        <div className="flex flex-col items-center">
          <p className="text-sm text-gray-500 mt-2">
            {uploadedFile.name} ({(uploadedFile.size / (1024 * 1024)).toFixed(2)} MB)
          </p>
          <div className="flex space-x-4 mt-4">
            <input
              type="file"
              id="change-video"
              className="hidden"
              accept="video/*"
              onChange={handleFileChange}
            />
            <label htmlFor="change-video">
              <GradientButton variant="outline" type="button" as="span" tabIndex={0}>
                Change Video
              </GradientButton>
            </label>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoUploader;
