
import { useLocation } from "react-router-dom";

const Header = () => {
  const location = useLocation();
  const displayHeader = location.pathname !== "/";
  
  if (!displayHeader) return null;
  
  return (
    <header className="w-full py-4 px-6 flex items-center justify-center bg-white/80 backdrop-blur-sm border-b border-border fixed top-0 z-50">
      <div className="flex items-center">
        <div className="h-8 w-8 rounded-full bg-gradient-to-r from-autism-purple to-autism-blue flex items-center justify-center">
          <span className="text-white font-bold text-sm">A</span>
        </div>
        <h1 className="text-xl font-bold ml-2 bg-gradient-to-r from-autism-purple to-autism-blue bg-clip-text text-transparent">
          AutiSense
        </h1>
      </div>
    </header>
  );
};

export default Header;
