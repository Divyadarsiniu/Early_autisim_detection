
import { useLocation } from "react-router-dom";

const steps = [
  { path: "/name", label: "Name" },
  { path: "/age", label: "Age" },
  { path: "/video", label: "Video" },
  { path: "/analysis", label: "Analysis" }
];

const ProgressBar = () => {
  const location = useLocation();
  const currentPath = location.pathname;
  
  // Don't show progress bar on welcome page
  if (currentPath === "/") return null;
  
  // Find the current step index
  const currentIndex = steps.findIndex(step => step.path === currentPath);
  const progress = ((currentIndex + 1) / steps.length) * 100;
  
  return (
    <div className="fixed bottom-0 left-0 w-full h-2 bg-gray-200 z-50">
      <div 
        className="h-full bg-gradient-to-r from-autism-purple to-autism-blue transition-all duration-500 ease-in-out"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
};

export default ProgressBar;
