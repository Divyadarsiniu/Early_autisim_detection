
import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface CardProps {
  children: ReactNode;
  className?: string;
  interactive?: boolean;
}

const Card = ({ children, className, interactive = false }: CardProps) => {
  return (
    <div
      className={cn(
        "bg-white rounded-xl border border-border p-6 shadow-sm",
        interactive && "card-hover cursor-pointer",
        className
      )}
    >
      {children}
    </div>
  );
};

export default Card;
