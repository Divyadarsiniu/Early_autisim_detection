
import { toast } from "sonner";

// Define the base URL for the API
// In a real application, this would come from environment variables
const API_URL = "https://api.autisense.org";

// Define the types for the API responses
export interface AnalysisResult {
  id: string;
  riskPercentage: number;
  poseTracking: {
    name: string;
    value: number;
    color: string;
  }[];
  gestureRecognition: {
    name: string;
    value: number;
    color: string;
  }[];
  eyeGazeTracking: {
    name: string;
    value: number;
    color: string;
  }[];
  facialExpressions: {
    name: string;
    value: number;
    color: string;
  }[];
  overallAssessment: {
    name: string;
    value: number;
    color: string;
  }[];
}

// For demo purposes, we'll create mock data
const createMockAnalysis = (): AnalysisResult => {
  return {
    id: Math.random().toString(36).substr(2, 9),
    riskPercentage: Math.floor(Math.random() * 100),
    poseTracking: [
      { name: "Repetitive movements", value: 35, color: "#9B87F5" },
      { name: "Typical posture", value: 45, color: "#6FA8DC" },
      { name: "Atypical posture", value: 20, color: "#D6BCFA" },
    ],
    gestureRecognition: [
      { name: "Limited gestures", value: 40, color: "#9B87F5" },
      { name: "Normal gestures", value: 35, color: "#6FA8DC" },
      { name: "Repetitive gestures", value: 25, color: "#D6BCFA" },
    ],
    eyeGazeTracking: [
      { name: "Avoidant gaze", value: 45, color: "#9B87F5" },
      { name: "Eye contact", value: 30, color: "#6FA8DC" },
      { name: "Scanning", value: 25, color: "#D6BCFA" },
    ],
    facialExpressions: [
      { name: "Limited expressions", value: 50, color: "#9B87F5" },
      { name: "Normal expressions", value: 30, color: "#6FA8DC" },
      { name: "Atypical expressions", value: 20, color: "#D6BCFA" },
    ],
    overallAssessment: [
      { name: "Typical behavior", value: 40, color: "#6FA8DC" },
      { name: "Atypical behavior", value: 60, color: "#9B87F5" },
    ],
  };
};

// In a real app, this would be a real API call
export const analyzeVideo = async (file: File, name: string, age: number): Promise<AnalysisResult> => {
  // Show a loading toast
  const toastId = toast.loading("Analyzing video...");
  
  try {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // For demo purposes, we're returning mock data
    const result = createMockAnalysis();
    
    // Update toast to show success
    toast.success("Analysis complete!", { id: toastId });
    
    return result;
  } catch (error) {
    // Update toast to show error
    toast.error("Analysis failed. Please try again.", { id: toastId });
    throw error;
  }
};
