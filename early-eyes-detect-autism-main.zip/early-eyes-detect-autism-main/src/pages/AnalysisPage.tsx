
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import GradientButton from "@/components/GradientButton";
import Card from "@/components/Card";
import { useUser } from "@/context/UserContext";
import PieChart from "@/components/PieChart";
import { ArrowLeft } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const AnalysisPage = () => {
  const navigate = useNavigate();
  const { name, age, analysisResult } = useUser();

  // Redirect if no analysis result
  if (!analysisResult) {
    navigate("/video");
    return null;
  }

  const handleNewAnalysis = () => {
    navigate("/");
  };

  const getRiskLevel = (percentage: number) => {
    if (percentage < 30) return { level: "Low", color: "text-green-500" };
    if (percentage < 70) return { level: "Medium", color: "text-yellow-500" };
    return { level: "High", color: "text-red-500" };
  };

  const riskInfo = getRiskLevel(analysisResult.riskPercentage);

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50 p-6 pt-20 pb-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-4xl"
      >
        <Card className="w-full">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Analysis Results for {name}</h2>
            <span className="text-gray-500">Age: {age} years</span>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg mb-8">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-semibold">Overall Risk Assessment</h3>
              <span className={`font-bold text-xl ${riskInfo.color}`}>
                {riskInfo.level}
              </span>
            </div>
            
            <div className="flex items-center space-x-4">
              <Progress 
                value={analysisResult.riskPercentage} 
                className="h-3"
                indicatorClassName={`${
                  analysisResult.riskPercentage < 30 
                    ? "bg-green-500" 
                    : analysisResult.riskPercentage < 70 
                    ? "bg-yellow-500" 
                    : "bg-red-500"
                }`}
              />
              <span className="font-medium">{analysisResult.riskPercentage}%</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
              <PieChart 
                data={analysisResult.overallAssessment} 
                title="Overall Behavioral Assessment"
              />
            </div>
            <div>
              <PieChart 
                data={analysisResult.poseTracking} 
                title="Pose Tracking Analysis"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div>
              <PieChart 
                data={analysisResult.gestureRecognition} 
                title="Gesture Recognition"
              />
            </div>
            <div>
              <PieChart 
                data={analysisResult.eyeGazeTracking} 
                title="Eye Gaze Tracking"
              />
            </div>
            <div>
              <PieChart 
                data={analysisResult.facialExpressions} 
                title="Facial Expression Analysis"
              />
            </div>
          </div>
          
          <div className="bg-autism-soft-purple p-4 rounded-lg mb-8">
            <h3 className="font-semibold mb-2">Recommendations</h3>
            <p className="text-gray-700">
              Based on the analysis, we recommend consulting with a healthcare professional 
              for a comprehensive assessment. Early intervention is key for better outcomes.
            </p>
          </div>
          
          <div className="flex justify-end">
            <GradientButton onClick={handleNewAnalysis}>
              Start New Analysis
            </GradientButton>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default AnalysisPage;
