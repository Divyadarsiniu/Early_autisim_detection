
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import GradientButton from "@/components/GradientButton";
import Card from "@/components/Card";
import { useUser } from "@/context/UserContext";
import { Input } from "@/components/ui/input";

const NamePage = () => {
  const navigate = useNavigate();
  const { name, setName } = useUser();
  const [inputName, setInputName] = useState(name);
  const [error, setError] = useState("");

  const handleContinue = () => {
    if (!inputName.trim()) {
      setError("Please enter a name");
      return;
    }
    
    setName(inputName);
    navigate("/age");
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center gradient-bg p-6 pt-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="w-full">
          <h2 className="text-2xl font-bold text-center mb-6">What's the child's name?</h2>
          <div className="mb-6">
            <Input
              type="text"
              placeholder="Enter name"
              value={inputName}
              onChange={(e) => {
                setInputName(e.target.value);
                setError("");
              }}
              className={`w-full ${error ? "border-red-500" : ""}`}
            />
            {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
          </div>
          <div className="flex justify-end">
            <GradientButton onClick={handleContinue}>
              Continue
            </GradientButton>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default NamePage;
