
import { useNavigate } from "react-router-dom";
import GradientButton from "@/components/GradientButton";

const NotFound = () => {
  const navigate = useNavigate();

  const handleGoHome = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center gradient-bg p-6">
      <div className="text-center">
        <h1 className="text-6xl font-bold bg-gradient-to-r from-autism-purple to-autism-blue bg-clip-text text-transparent mb-4">
          404
        </h1>
        <h2 className="text-2xl font-semibold text-gray-700 mb-6">Page Not Found</h2>
        <p className="text-gray-500 mb-8">
          The page you are looking for doesn't exist or has been moved.
        </p>
        <GradientButton onClick={handleGoHome}>
          Go to Home
        </GradientButton>
      </div>
    </div>
  );
};

export default NotFound;
