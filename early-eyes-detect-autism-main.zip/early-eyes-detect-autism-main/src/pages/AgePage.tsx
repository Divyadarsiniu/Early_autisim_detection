
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import GradientButton from "@/components/GradientButton";
import Card from "@/components/Card";
import { useUser } from "@/context/UserContext";
import { Slider } from "@/components/ui/slider";
import { ArrowLeft } from "lucide-react";

const AgePage = () => {
  const navigate = useNavigate();
  const { age, setAge } = useUser();
  const [sliderAge, setSliderAge] = useState<number[]>(age ? [age] : [2]);

  const handleContinue = () => {
    setAge(sliderAge[0]);
    navigate("/video");
  };

  const handleBack = () => {
    navigate("/name");
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center gradient-bg p-6 pt-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="w-full">
          <button 
            onClick={handleBack}
            className="absolute top-4 left-4 text-gray-500 hover:text-autism-purple transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          
          <h2 className="text-2xl font-bold text-center mb-6">How old is the child?</h2>
          <div className="mb-10 px-4">
            <div className="text-center mb-8">
              <span className="text-5xl font-bold text-autism-purple">{sliderAge[0]}</span>
              <span className="text-lg ml-2">years old</span>
            </div>
            
            <Slider
              defaultValue={sliderAge}
              max={18}
              min={1}
              step={1}
              onValueChange={setSliderAge}
              className="mb-4"
            />
            
            <div className="flex justify-between text-sm text-gray-500">
              <span>1 year</span>
              <span>18 years</span>
            </div>
          </div>
          
          <div className="flex justify-end">
            <GradientButton onClick={handleContinue}>
              Continue
            </GradientButton>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default AgePage;
