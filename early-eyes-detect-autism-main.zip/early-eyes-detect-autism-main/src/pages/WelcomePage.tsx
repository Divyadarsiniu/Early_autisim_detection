
import { useNavigate } from "react-router-dom";
import GradientButton from "@/components/GradientButton";
import { motion } from "framer-motion";

const WelcomePage = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate("/name");
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center gradient-bg p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-md w-full flex flex-col items-center"
      >
        <div className="h-20 w-20 rounded-full bg-gradient-to-r from-autism-purple to-autism-blue flex items-center justify-center mb-6">
          <span className="text-white font-bold text-2xl">A</span>
        </div>
        <h1 className="text-4xl font-bold text-center bg-gradient-to-r from-autism-purple to-autism-blue bg-clip-text text-transparent mb-4">
          AutiSense
        </h1>
        <p className="text-lg text-center text-gray-700 mb-8">
          Early autism detection through AI-powered analysis of behavior, 
          gestures, eye gaze, and facial expressions
        </p>
        <GradientButton onClick={handleGetStarted} className="px-8 py-6 text-lg">
          Get Started
        </GradientButton>
        <p className="text-sm text-gray-500 mt-8 text-center max-w-sm">
          AutiSense uses computer vision and machine learning to help identify
          early signs of autism in children through video analysis
        </p>
      </motion.div>
    </div>
  );
};

export default WelcomePage;
