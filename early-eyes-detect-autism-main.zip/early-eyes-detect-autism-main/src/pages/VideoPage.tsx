
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import GradientButton from "@/components/GradientButton";
import Card from "@/components/Card";
import { useUser } from "@/context/UserContext";
import VideoUploader from "@/components/VideoUploader";
import { ArrowLeft } from "lucide-react";
import { analyzeVideo } from "@/services/api";
import { useToast } from "@/components/ui/use-toast";

const VideoPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { name, age, setVideoFile, setAnalysisResult } = useUser();
  const [uploadedVideo, setUploadedVideo] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleVideoUploaded = (file: File) => {
    setUploadedVideo(file);
    setVideoFile(file);
  };

  const handleBack = () => {
    navigate("/age");
  };

  const handleAnalyze = async () => {
    if (!uploadedVideo) {
      toast({
        title: "No video selected",
        description: "Please upload a video before continuing.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    
    try {
      const result = await analyzeVideo(uploadedVideo, name, age);
      setAnalysisResult(result);
      navigate("/analysis");
    } catch (error) {
      console.error("Analysis error:", error);
      toast({
        title: "Analysis failed",
        description: "There was an error analyzing the video. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center gradient-bg p-6 pt-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl"
      >
        <Card className="w-full">
          <button 
            onClick={handleBack}
            className="absolute top-4 left-4 text-gray-500 hover:text-autism-purple transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          
          <h2 className="text-2xl font-bold text-center mb-6">Upload a video for analysis</h2>
          <p className="text-center text-gray-500 mb-6">
            Upload a video (up to 100MB) of the child engaging in natural play or activities
          </p>
          
          <VideoUploader onVideoUploaded={handleVideoUploaded} />
          
          <div className="flex justify-end mt-6">
            <GradientButton 
              onClick={handleAnalyze}
              disabled={!uploadedVideo || isAnalyzing}
            >
              {isAnalyzing ? "Analyzing..." : "Analyze Video"}
            </GradientButton>
          </div>
          
          <div className="mt-6 text-sm text-gray-500">
            <p className="text-center">
              The video will be analyzed for behavioral markers including:
            </p>
            <ul className="list-disc list-inside mt-2 grid grid-cols-2 gap-1">
              <li>Pose tracking</li>
              <li>Gesture recognition</li>
              <li>Eye gaze patterns</li>
              <li>Facial expressions</li>
            </ul>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default VideoPage;
