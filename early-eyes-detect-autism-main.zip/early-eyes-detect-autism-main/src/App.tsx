
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// Pages
import WelcomePage from "./pages/WelcomePage";
import NamePage from "./pages/NamePage";
import AgePage from "./pages/AgePage";
import VideoPage from "./pages/VideoPage";
import AnalysisPage from "./pages/AnalysisPage";
import NotFound from "./pages/NotFound";

// Components
import Header from "./components/Header";
import ProgressBar from "./components/ProgressBar";

// Context
import { UserProvider } from "./context/UserContext";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <UserProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Header />
          <ProgressBar />
          <Routes>
            <Route path="/" element={<WelcomePage />} />
            <Route path="/name" element={<NamePage />} />
            <Route path="/age" element={<AgePage />} />
            <Route path="/video" element={<VideoPage />} />
            <Route path="/analysis" element={<AnalysisPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </UserProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
